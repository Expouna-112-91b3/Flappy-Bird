"""
classe para realizar qualquer tipo de teste
"""

class Test:
    class logger:
        def log(text):
            print(f"{text}")


Test.logger.log("Hello world!")
