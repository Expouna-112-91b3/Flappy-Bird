from enum import Enum

class Scenes(Enum):
    MENU = 0
    SINGLEPLAYER = 1
    SCORE_BOARD = 2